package com.kbs.mydbdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddUserActivity extends Activity {
    EditText editTextUsername,editTextUserAge,editTextUserCity;
    DBHelper dbHelper;
    User editUser;
    Button btnadd,btnedit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);
        editTextUsername=(EditText)findViewById(R.id.etusername);
        editTextUserAge=(EditText)findViewById(R.id.etuage);
        editTextUserCity=(EditText)findViewById(R.id.etcity);
        btnadd=(Button)findViewById(R.id.btnAdd);
        btnedit=(Button)findViewById(R.id.btnedit);
        dbHelper=new DBHelper(AddUserActivity.this);

        //check for edit or add new
        if(getIntent().getExtras()!=null)
        {
           int id=getIntent().getExtras().getInt("editid",0);
            btnedit.setEnabled(true);
            btnadd.setEnabled(false);
            if(id!=0)
            {
                editUser=dbHelper.getUser(id);
                editTextUsername.setText(editUser.getUsername());
                editTextUserAge.setText(editUser.getUserage()+"");
                editTextUserCity.setText(editUser.getUsercity());
            }
        }
        else
        {
            btnedit.setEnabled(false);
            btnadd.setEnabled(true);
        }

    }
    public void btn_add_user(View v)
    {
        String name,city;
        int age;
        name=editTextUsername.getText().toString();
        city=editTextUserCity.getText().toString();
        age=Integer.parseInt(editTextUserAge.getText().toString());
        if(dbHelper.insertUser(name,age,city)!=-1)
        {
            Toast.makeText(this, "User Added", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this, "Problem in insert", Toast.LENGTH_SHORT).show();
        }
        editTextUserCity.setText("");
        editTextUsername.setText("");
        editTextUserAge.setText("");
        this.finish();
    }

    public void btn_edit_user(View v){
        String name,city;
        int age;
        name=editTextUsername.getText().toString();
        city=editTextUserCity.getText().toString();
        age=Integer.parseInt(editTextUserAge.getText().toString());
        if(dbHelper.updateUser(editUser.getId(),name,age,city)!=-1)
        {
            Toast.makeText(this, "User Update", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this, "Problem in Update", Toast.LENGTH_SHORT).show();
        }
        editTextUserCity.setText("");
        editTextUsername.setText("");
        editTextUserAge.setText("");
        this.finish();
    }
}
