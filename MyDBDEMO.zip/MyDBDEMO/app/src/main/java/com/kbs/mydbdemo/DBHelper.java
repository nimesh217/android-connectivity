package com.kbs.mydbdemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by nimes on 25-01-2023.
 */

public class DBHelper extends SQLiteOpenHelper{
    DBHelper(Context context)
    {
        super(context,"mydb.db",null,1);

    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        //table creation
        db.execSQL("create table users (" +
                "id integer primary key autoincrement," +
                "username text," +
                "userage integer," +
                "usercity text);");

        //db.rawQuery();
        //db.query();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table users");
        onCreate(db);
    }

    public ArrayList<String> getAllUsers1() {
        //select * from users;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cusers = db.rawQuery("select * from users", null);
        cusers.moveToFirst();
        ArrayList<String> userList=new ArrayList<>();
        //User tempUser;
        String name;
        while (!cusers.isAfterLast())
        {
//            tempUser=new User();
//            tempUser.setId(cusers.getInt(0));
//            tempUser.setUsername(cusers.getString(1));
//            tempUser.setUserage(cusers.getInt(2));
//            tempUser.setUsercity(cusers.getString(3));
            //userList.add(tempUser);
            name=cusers.getInt(0)+":"+cusers.getString(1)+":"+cusers.getInt(2)+":"+cusers.getString(3);
            userList.add(name);
            cusers.moveToNext();
        }
        return userList;
    }
    public ArrayList<User> getAllUsersNew() {
        //select * from users;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cusers = db.rawQuery("select * from users", null);
        cusers.moveToFirst();
        ArrayList<User> userList=new ArrayList<>();
        User tempUser;
        //String name;
        while (!cusers.isAfterLast())
        {
            tempUser=new User();
            tempUser.setId(cusers.getInt(0));
            tempUser.setUsername(cusers.getString(1));
            tempUser.setUserage(cusers.getInt(2));
            tempUser.setUsercity(cusers.getString(3));
            userList.add(tempUser);
            //name=cusers.getInt(0)+":"+cusers.getString(1)+":"+cusers.getInt(2)+":"+cusers.getString(3);

            cusers.moveToNext();
        }
        return userList;
    }
    public User getUser(int id)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor c=db.rawQuery("select * from users where id="+id,null);
        c.moveToFirst();
        User tempuser=new User();
        tempuser.setId(c.getInt(0));
        tempuser.setUsername(c.getString(1));
        tempuser.setUserage(c.getInt(2));
        tempuser.setUsercity(c.getString(3));

        return tempuser;
    }
    public long insertUser(String name,int age,String city)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("username",name);
        cv.put("userage",age);
        cv.put("usercity",city);
        long rowid= db.insert("users",null,cv);
        return rowid;
    }
    public int deleteUser(int id)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        String args[]={id+""};

        int res= db.delete("users","id=?",args);
        return res;
    }
    public long updateUser(int id,String name,int age,String city)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        String args[]={id+""};
        cv.put("username",name);
        cv.put("userage",age);
        cv.put("usercity",city);
        long rowid= db.update("users",cv,"id=?",args);
        return rowid;
    }
}
