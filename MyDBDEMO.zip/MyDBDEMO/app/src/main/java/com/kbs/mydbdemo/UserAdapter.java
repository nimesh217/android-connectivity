package com.kbs.mydbdemo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.zip.Inflater;

/**
 * Created by nimes on 25-01-2023.
 */

public class UserAdapter extends BaseAdapter {
    Context context;
    final ArrayList<User> userslist;

    UserAdapter(Context context, ArrayList<User> userArrayList)
    {
        this.context=context;
        this.userslist=userArrayList;
    }

    @Override
    public int getCount() {
        return userslist.size();
    }

    @Override
    public Object getItem(int position) {
        return userslist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return userslist.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        LayoutInflater inflater;
        if(convertView == null)
        {
            inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.user_custom_layout,null);
            holder=new Holder();
            holder.tv1=(TextView) convertView.findViewById(R.id.tvid);
            holder.tv2=(TextView) convertView.findViewById(R.id.tvusername);
            holder.tv3=(TextView) convertView.findViewById(R.id.tvuserage);
            holder.tv4=(TextView) convertView.findViewById(R.id.tvusercity);
            holder.img1=(ImageView)convertView.findViewById(R.id.img1);
            convertView.setTag(holder);
        }
        else
        {
            holder=(Holder) convertView.getTag();
        }
        holder.tv1.setText(userslist.get(position).getId()+"");
        holder.tv2.setText(userslist.get(position).getUsername());
        holder.tv3.setText(userslist.get(position).getUserage()+"");
        holder.tv4.setText(userslist.get(position).getUsercity());

        return convertView;
    }
    public class Holder
    {
        TextView tv1,tv2,tv3,tv4;
        ImageView img1;
    }
}
