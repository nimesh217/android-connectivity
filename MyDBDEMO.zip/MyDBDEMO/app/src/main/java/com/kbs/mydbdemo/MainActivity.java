package com.kbs.mydbdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    ListView listViewUsers;
    DBHelper dbHelper;
    //ArrayAdapter adapter;
    UserAdapter uadapter;
    ArrayList<User> userarraylist;
    //ArrayList<String> userarraylist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewUsers=(ListView) findViewById(R.id.lvusers);

        dbHelper=new DBHelper(MainActivity.this);
        userarraylist=new ArrayList<>();
        userarraylist=dbHelper.getAllUsersNew();

        //usernamearrayList.addAll(userarraylist.get())
       // adapter=new ArrayAdapter(MainActivity.this,android.R.layout.simple_list_item_1,userarraylist);
        uadapter=new UserAdapter(getApplicationContext(),userarraylist);
        listViewUsers.setAdapter(uadapter);

        //on item click of listview edit
        listViewUsers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //we will take id from here and go to add_user_activity and fill the data
                Intent myintent=new Intent(MainActivity.this,AddUserActivity.class);
                myintent.putExtra("editid",userarraylist.get(position).getId());
                startActivity(myintent);
            }
        });

        //onlong click of listview delete
        listViewUsers.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if(dbHelper.deleteUser(userarraylist.get(position).getId())!=-1)
                {
                    Toast.makeText(MainActivity.this, "User Deleted", Toast.LENGTH_SHORT).show();
                    //userarraylist=dbHelper.getAllUsersNew();
                    userarraylist.remove(position);
                    uadapter.notifyDataSetChanged();
                }else
                {
                    Toast.makeText(MainActivity.this, "Problem in Deletion", Toast.LENGTH_SHORT).show();

                }
                return true;
            }
        });
    }

    public void btn_gotonext_click(View v)
    {
        //go to add user activity
        Intent myintent=new Intent(MainActivity.this,AddUserActivity.class);
        startActivity(myintent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        userarraylist=dbHelper.getAllUsersNew();
        uadapter.notifyDataSetChanged();
    }
}
