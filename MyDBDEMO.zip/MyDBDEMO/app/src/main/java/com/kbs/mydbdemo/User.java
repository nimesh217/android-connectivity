package com.kbs.mydbdemo;

/**
 * Created by nimes on 25-01-2023.
 */

public class User {
    int id,userage;
    String username,usercity;

    User()
    {

    }
    User(int id,String uname,int usage,String ucity)
    {
        this.id=id;
        this.username=uname;
        this.userage=usage;
        this.usercity=ucity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserage() {
        return userage;
    }

    public void setUserage(int userage) {
        this.userage = userage;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsercity() {
        return usercity;
    }

    public void setUsercity(String usercity) {
        this.usercity = usercity;
    }
}
